<?php
/**
 * generate_document.php
 * Unified document generator — supports both DOCX and PDF output.
 *
 * Public API (used by upload_document.php):
 *   generateDocument($template, $data, $title, $format, $collaboratedLogo, $orgName, $orgTagline, $orgLogoPath)
 *     $format : 'docx' | 'pdf'
 *     returns : absolute path to the generated temp file, or false on failure
 */

function generateDocument($template, $data, $title, $format = 'docx', $collaboratedLogo = null, $organizationName = null, $organizationTagline = null, $orgLogoPath = null, $controlNumber = null) {
    $format = strtolower($format);

    $docxPath = generateDocx($template, $data, $title, $collaboratedLogo, $organizationName, $organizationTagline, $orgLogoPath, $controlNumber);
    if (!$docxPath) return false;

    if ($format !== 'pdf') return $docxPath;

    $tmpDir  = sys_get_temp_dir();
    $soffice = findLibreOffice();
    if (!$soffice) {
        error_log('generateDocument: LibreOffice not found, returning DOCX instead');
        return $docxPath;
    }

    $cmd  = sprintf('"%s" --headless --convert-to pdf --outdir "%s" "%s" 2>&1', $soffice, $tmpDir, $docxPath);
    exec($cmd, $out, $code);
    @unlink($docxPath);

    $pdfPath = $tmpDir . '/' . pathinfo($docxPath, PATHINFO_FILENAME) . '.pdf';
    return ($code === 0 && file_exists($pdfPath)) ? $pdfPath : false;
}

function findLibreOffice() {
    $paths = [
        'C:\\Program Files\\LibreOffice\\program\\soffice.exe',
        'C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe',
        '/usr/bin/soffice',
        '/usr/lib/libreoffice/program/soffice',
        '/opt/libreoffice/program/soffice',
    ];
    foreach ($paths as $p) {
        if (file_exists($p)) return $p;
    }
    $found = trim((string)@shell_exec(PHP_OS_FAMILY === 'Windows' ? 'where soffice.exe 2>nul' : 'which soffice 2>/dev/null'));
    return $found ? strtok($found, "\r\n") : null;
}

/* ══════════════════════════════════════════════════════════════════════════════
 * DOCX GENERATION
 * ══════════════════════════════════════════════════════════════════════════════ */

function generateDocx($template, $data, $title, $collaboratedLogo = null, $organizationName = null, $organizationTagline = null, $orgLogoPath = null, $controlNumber = null) {
    $tempDir  = sys_get_temp_dir();
    $docxPath = $tempDir . '/' . uniqid('doc_') . '.docx';

    if (!class_exists('ZipArchive')) {
        error_log('generateDocx: ZipArchive not available');
        return false;
    }

    $zip = new ZipArchive();
    if ($zip->open($docxPath, ZipArchive::CREATE) !== true) {
        error_log('generateDocx: could not create zip at ' . $docxPath);
        return false;
    }

    $xmlContent = createDocumentXml($title, $template, $data, $collaboratedLogo, $organizationName, $organizationTagline, $orgLogoPath, $controlNumber);

    $zip->addFromString('[Content_Types].xml',          getContentTypes());
    $zip->addFromString('_rels/.rels',                  getRelationships());
    $zip->addFromString('word/_rels/document.xml.rels', getDocumentRelationships($collaboratedLogo, $orgLogoPath));
    $zip->addFromString('word/document.xml',            $xmlContent);

    // Base: cig_user/ — two levels up from php/
    $_genBase   = dirname(dirname(__DIR__));
    $_genAssets = $_genBase . DIRECTORY_SEPARATOR . 'Assets' . DIRECTORY_SEPARATOR;

    // Left logo: Admission.png from Assets
    $logoPath = '';
    foreach (['Admission.png', 'admission.png', 'Admission.jpg', 'admission.jpg'] as $_af) {
        if (file_exists($_genAssets . $_af)) { $logoPath = $_genAssets . $_af; break; }
    }
    if (!$logoPath) {
        foreach ([$_genBase . '/plsplogo.png', $_genBase . '/Assets/plsplogo.png'] as $_pf) {
            if (file_exists($_pf)) { $logoPath = $_pf; break; }
        }
    }
    if ($logoPath && file_exists($logoPath)) {
        $imageData = file_get_contents($logoPath);
        if ($imageData) {
            $ext = strtolower(pathinfo($logoPath, PATHINFO_EXTENSION)) ?: 'png';
            $zip->addFromString('word/media/image1.' . $ext, $imageData);
        }
    }

    // Collaborated logo (image2)
    if ($collaboratedLogo) {
        $collabFile = basename($collaboratedLogo);
        $collabPath = $_genAssets . $collabFile;
        if (!file_exists($collabPath)) {
            foreach (scandir($_genAssets) as $_cf) {
                if (strcasecmp($_cf, $collabFile) === 0) {
                    $collabPath = $_genAssets . $_cf;
                    break;
                }
            }
        }
        if (file_exists($collabPath)) {
            $imageData = file_get_contents($collabPath);
            if ($imageData) {
                $ext = strtolower(pathinfo($collabPath, PATHINFO_EXTENSION));
                $zip->addFromString('word/media/image2.' . $ext, $imageData);
            }
        } else {
            error_log("Collaborated logo not found: $collabPath");
        }
    }

    // Org logo (image3)
    if (!empty($orgLogoPath) && file_exists($orgLogoPath)) {
        $imageData = file_get_contents($orgLogoPath);
        if ($imageData) {
            $ext = strtolower(pathinfo($orgLogoPath, PATHINFO_EXTENSION)) ?: 'jpg';
            $zip->addFromString('word/media/image3.' . $ext, $imageData);
        }
    }

    $zip->close();
    return file_exists($docxPath) ? $docxPath : false;
}

// ── XML helpers ──────────────────────────────────────────────────────────────

function createDocumentXml($title, $template, $data, $collaboratedLogo = null, $organizationName = null, $organizationTagline = null, $orgLogoPath = null, $controlNumber = null) {
    $docTitle   = htmlspecialchars($title);
    $orgName    = htmlspecialchars($organizationName ?: 'Organization');
    $orgTagline = htmlspecialchars($organizationTagline ?: '');

    $c  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
    $c .= '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" ';
    $c .= 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
    $c .= '<w:body>';

    // ── Header table ──
    $c .= '<w:tbl><w:tblPr>';
    $c .= '<w:tblW w:w="9200" w:type="dxa"/>';
    $c .= '<w:tblBorders>'
        . '<w:top w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        . '<w:left w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        . '<w:bottom w:val="single" w:sz="12" w:space="5" w:color="2F5233"/>'
        . '<w:right w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        . '<w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        . '<w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        . '</w:tblBorders>';
    $c .= '<w:tblCellMar><w:top w:w="100" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="100" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar>';
    $c .= '</w:tblPr><w:tr>';

    // Left cell - PLSP logo (Admission.png)
    $c .= '<w:tc><w:tcPr><w:tcW w:w="2800" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>';
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr>';
    $c .= docxInlineImage('rId4', 1, 'Logo', '700000', '700000');
    $c .= '</w:p></w:tc>';

    // Middle cell - Org info
    $c .= '<w:tc><w:tcPr><w:tcW w:w="3600" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>';
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>PAMANTASAN NG LUNGSOD NG SAN PABLO</w:t></w:r></w:p>';
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>' . $orgName . '</w:t></w:r></w:p>';
    if (!empty(trim($orgTagline))) {
        $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:i/><w:sz w:val="20"/></w:rPr><w:t>&#x201C;' . $orgTagline . '&#x201D;</w:t></w:r></w:p>';
    }
    if (!empty($controlNumber)) {
        $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr>'
            . '<w:r><w:rPr><w:sz w:val="18"/><w:color w:val="888888"/></w:rPr>'
            . '<w:t>Control No.: ' . htmlspecialchars($controlNumber) . '</w:t></w:r></w:p>';
    }
    $c .= '</w:tc>';

    // Right cell — org logo (image3) + collaborated logo (image2), side by side
    $c .= '<w:tc><w:tcPr><w:tcW w:w="2800" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>';
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr>';

    $hasOrgLogo   = !empty($orgLogoPath) && file_exists($orgLogoPath);
    $hasCollabLogo = !empty($collaboratedLogo);

    if ($hasOrgLogo) {
        $c .= docxInlineImage('rId6', 3, 'OrgLogo', '700000', '700000');
    }
    if ($hasCollabLogo) {
        if ($hasOrgLogo) {
            $c .= '<w:r><w:t xml:space="preserve"> </w:t></w:r>';
        }
        $c .= docxInlineImage('rId5', 2, 'CollaboratedLogo', '700000', '700000');
    }
    $c .= '</w:p>';
    $c .= '</w:tc>';

    $c .= '</w:tr></w:tbl>';

    // Body content
    if (isset($template['name']) && $template['name'] === 'Project Proposal') {
        // Make control number accessible inside the content builder via $data
        if (!empty($controlNumber)) {
            $data['control_number'] = $controlNumber;
        }
        // FEATURE 3 (WYSIWYG): use multi-line-aware builder for accurate output
        $c .= buildProjectProposalContentWysiwyg($data, $organizationName);
    } else {
        $c .= '<w:p/>';
        // Control number for non-project-proposal templates — right-aligned, above the title
        if (!empty($controlNumber)) {
            $c .= '<w:p><w:pPr><w:jc w:val="right"/></w:pPr>'
                . '<w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="2F5233"/></w:rPr>'
                . '<w:t>Control No.: ' . htmlspecialchars($controlNumber) . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>' . $docTitle . '</w:t></w:r></w:p>';
        $c .= '<w:p/>';
        foreach ($template['fields'] as $fieldId => $fieldLabel) {
            $fieldValue = isset($data[$fieldId]) ? htmlspecialchars($data[$fieldId]) : '';
            $c .= '<w:p><w:r><w:rPr><w:b/><w:color w:val="2F5233"/></w:rPr><w:t>' . htmlspecialchars($fieldLabel) . ':</w:t></w:r></w:p>';
            foreach (explode("\n", $fieldValue) as $line) {
                $c .= '<w:p><w:pPr><w:ind w:left="720"/></w:pPr><w:r><w:t>' . ($line ?: ' ') . '</w:t></w:r></w:p>';
            }
            $c .= '<w:p/>';
        }
    }

    // Footer
    $c .= '<w:p/>';
    $c .= '<w:p><w:pPr><w:pBdr><w:top w:val="single" w:sz="24" w:space="1" w:color="000000"/></w:pBdr></w:pPr></w:p>';
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:i/><w:sz w:val="22"/></w:rPr><w:t>&#x201C;Primed to Lead and Serve for Progress&#x201D;</w:t></w:r></w:p>';
    $c .= '<w:sectPr><w:pgMar w:top="1080" w:right="1080" w:bottom="1080" w:left="1080" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>';
    $c .= '</w:body></w:document>';

    return $c;
}

function docxInlineImage($rId, $docPrId, $name, $cx, $cy) {
    $r  = '<w:r><w:drawing>';
    $r .= '<wp:inline distT="0" distB="0" distL="0" distR="0" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">';
    $r .= '<wp:extent cx="' . $cx . '" cy="' . $cy . '"/>';
    $r .= '<wp:effectExtent l="0" t="0" r="0" b="0"/>';
    $r .= '<wp:docPr id="' . $docPrId . '" name="' . $name . '"/>';
    $r .= '<wp:cNvGraphicFramePr><a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/></wp:cNvGraphicFramePr>';
    $r .= '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">';
    $r .= '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">';
    $r .= '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">';
    $r .= '<pic:nvPicPr><pic:cNvPr id="0" name="' . $name . '"/><pic:cNvPicPr/></pic:nvPicPr>';
    $r .= '<pic:blipFill><a:blip r:embed="' . $rId . '" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>';
    $r .= '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' . $cx . '" cy="' . $cy . '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>';
    $r .= '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>';
    return $r;
}

function getContentTypes() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml"  ContentType="application/xml"/>'
        . '<Default Extension="png"  ContentType="image/png"/>'
        . '<Default Extension="jpg"  ContentType="image/jpeg"/>'
        . '<Default Extension="jpeg" ContentType="image/jpeg"/>'
        . '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        . '</Types>';
}

function getRelationships() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        . '</Relationships>';
}

function getDocumentRelationships($collaboratedLogo = null, $orgLogoPath = null) {
    $r  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';

    // rId4 = left logo (Admission.png)
    $r .= '<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>';

    // rId5 = collaborated logo (image2)
    if ($collaboratedLogo) {
        $ext = strtolower(pathinfo(basename($collaboratedLogo), PATHINFO_EXTENSION));
        if (!$ext) $ext = 'jpg';
        $r .= '<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image2.' . $ext . '"/>';
    }

    // rId6 = org logo (image3)
    if (!empty($orgLogoPath) && file_exists($orgLogoPath)) {
        $ext = strtolower(pathinfo($orgLogoPath, PATHINFO_EXTENSION));
        if (!$ext) $ext = 'jpg';
        $r .= '<Relationship Id="rId6" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image3.' . $ext . '"/>';
    }

    $r .= '</Relationships>';
    return $r;
}

/* ══════════════════════════════════════════════════════════════════════════════
 * PROJECT PROPOSAL DOCX CONTENT
 * ══════════════════════════════════════════════════════════════════════════════ */

function buildProjectProposalContent($data, $organizationName = null) {
    $c = '';
    $orgName = htmlspecialchars($organizationName ?: ($data['organization'] ?? ''));

    // ── Control Number (right-aligned, above date) ──
    if (!empty($data['control_number'])) {
        $c .= '<w:p><w:pPr><w:jc w:val="right"/></w:pPr>'
            . '<w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="2F5233"/></w:rPr>'
            . '<w:t>Control No.: ' . htmlspecialchars($data['control_number']) . '</w:t></w:r></w:p>';
    }

    // ── Date (left-aligned, bold) ──
    if (!empty($data['proposal_date'])) {
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($data['proposal_date']) . '</w:t></w:r></w:p><w:p/>';
    }

    // ── Recipient 1 — name + title from site_settings (super admin controlled) ──
    if (!empty($data['recipient_1'])) {
        $r1title = htmlspecialchars(trim($data['recipient_1_title'] ?? 'Interim University President'));
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars(trim($data['recipient_1'])) . '</w:t></w:r></w:p>';
        $c .= '<w:p><w:r><w:t>' . $r1title . '</w:t></w:r></w:p>';
        $c .= '<w:p/>';
    }

    // ── Recipient 2 — name + title from site_settings (super admin controlled) ──
    if (!empty($data['recipient_2'])) {
        $r2title = htmlspecialchars(trim($data['recipient_2_title'] ?? 'Dean, Office of Student Affairs and Services'));
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars(trim($data['recipient_2'])) . '</w:t></w:r></w:p>';
        $c .= '<w:p><w:r><w:t>' . $r2title . '</w:t></w:r></w:p>';
        $c .= '<w:p/>';
    }

    // ── Dear line — dynamic: uses recipient_2 name (Dean) ──
    $dearName = trim($data['recipient_2'] ?? '');
    if ($dearName) {
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Dear ' . htmlspecialchars($dearName) . ',</w:t></w:r></w:p>';
    }

    // ── Opening statement (no label shown) ──
    if (!empty($data['opening_statement'])) {
        $c .= '<w:p/>';
        foreach (explode("\n", $data['opening_statement']) as $line) {
            $c .= '<w:p><w:r><w:t>' . htmlspecialchars(trim($line) ?: ' ') . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p/>';
    }

    // ── PROJECT PROPOSAL heading ──
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>PROJECT PROPOSAL</w:t></w:r></w:p>';
    $c .= '<w:p/>';

    // ── I. Identifying Information ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>I. Identifying Information</w:t></w:r></w:p>';
    $c .= docxTable([
        ['Organization',             $data['organization']         ?? ''],
        ['Project Title',            $data['project_title']        ?? ''],
        ['Type of Project',          $data['project_type']         ?? ''],
        ['Project Involvement',      $data['project_involvement']  ?? ''],
        ['Project Location',         $data['project_location']     ?? ''],
        ['Proposed Start Date & Time',$data['proposed_start_date'] ?? ''],
        ['Proposed Completion Date', $data['proposed_end_date']    ?? ''],
        ['Number of Participants',   $data['number_participants']  ?? ''],
    ]);
    $c .= '<w:p/>';

    // ── II. Project Description ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>II. Project Description</w:t></w:r></w:p>';

    // A. Summary
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>A. SUMMARY OF THE PROJECT</w:t></w:r></w:p>';
    $c .= docxIndentedText($data['project_summary'] ?? '');
    $c .= '<w:p/>';

    // B. Project Goal and Objectives (inserted after Summary)
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>B. PROJECT GOAL AND OBJECTIVES</w:t></w:r></w:p>';
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Goal:</w:t></w:r></w:p>';
    $c .= docxIndentedText($data['project_goal'] ?? '');
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Objectives:</w:t></w:r></w:p>';
    if (!empty($data['project_objectives'])) {
        $n = 1;
        foreach (explode("\n", $data['project_objectives']) as $obj) {
            $obj = trim($obj);
            if ($obj !== '') {
                $c .= '<w:p><w:pPr><w:ind w:left="720"/></w:pPr><w:r><w:t>' . $n++ . '. ' . htmlspecialchars($obj) . '</w:t></w:r></w:p>';
            }
        }
    }
    $c .= '<w:p/>';

    // C. Expected Outputs
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>C. EXPECTED OUTPUTS</w:t></w:r></w:p>';
    $c .= docxBulletList($data['expected_outputs'] ?? '');
    $c .= '<w:p/>';

    // ── III. Budget ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>III. Budget</w:t></w:r></w:p>';
    $c .= docxTable([
        ['Source of Fund',           $data['budget_source']  ?? ''],
        ['Partner/Donation/Subsidy', $data['budget_partner'] ?? ''],
        ['Total Project Cost',       $data['budget_total']   ?? ''],
    ]);
    $c .= '<w:p/>';

    // ── IV. Monitoring and Evaluation ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>IV. Monitoring and Evaluation</w:t></w:r></w:p>';
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Monitoring:</w:t></w:r></w:p>';
    $c .= docxBulletList($data['monitoring_details'] ?? '');
    $c .= '<w:p/>';
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Evaluation Strategy:</w:t></w:r></w:p>';
    $c .= docxBulletList($data['evaluation_details'] ?? '');
    $c .= '<w:p/>';

    // ── V. Security Plan ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>V. Security Plan</w:t></w:r></w:p>';
    $c .= docxBulletList($data['security_plan'] ?? '');
    $c .= '<w:p/><w:p/>';

    // ── Closing statement (no label, italic) ──
    if (!empty($data['closing_statement'])) {
        foreach (explode("\n", $data['closing_statement']) as $line) {
            $c .= '<w:p><w:r><w:rPr><w:i/></w:rPr><w:t>' . htmlspecialchars(trim($line) ?: ' ') . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p/>';
    }

    // ── "Sincerely," (auto-added after closing) ──
    $c .= '<w:p><w:r><w:t>Sincerely,</w:t></w:r></w:p>';
    $c .= '<w:p/><w:p/>';

    // ── Sender — name on line 1 (bold), title/org on subsequent lines ──
    if (!empty($data['sender_name'])) {
        $sLines = array_values(array_filter(array_map('trim', explode("\n", $data['sender_name']))));
        if (!empty($sLines)) {
            $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($sLines[0]) . '</w:t></w:r></w:p>';
            for ($li=1; $li<count($sLines); $li++) {
                $c .= '<w:p><w:r><w:t>' . htmlspecialchars($sLines[$li]) . '</w:t></w:r></w:p>';
            }
        }
    }
    $c .= '<w:p/>';

    // ── Noted by (no header, names/titles only) ──
    $noteList = ['adviser_name','co_adviser_name'];
    // Support dynamic extra signatories: additional_signer_1 .. additional_signer_5
    for ($si=1; $si<=5; $si++) {
        $noteList[] = 'additional_signer_' . $si;
    }
    foreach ($noteList as $sigKey) {
        if (empty($data[$sigKey])) continue;
        // Each field: "Name\nTitle\nOrg" (newline-separated lines)
        $sigLines = array_values(array_filter(array_map('trim', explode("\n", $data[$sigKey]))));
        if (empty($sigLines)) continue;
        // Line 0 = bold name
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($sigLines[0]) . '</w:t></w:r></w:p>';
        // Remaining lines = title/org (normal weight)
        for ($li=1; $li<count($sigLines); $li++) {
            $c .= '<w:p><w:r><w:t>' . htmlspecialchars($sigLines[$li]) . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p/>';
    }

    // ── Endorsed by (no header) ──
    if (!empty($data['endorsed_by'])) {
        $eLines = array_values(array_filter(array_map('trim', explode("\n", $data['endorsed_by']))));
        if (!empty($eLines)) {
            $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($eLines[0]) . '</w:t></w:r></w:p>';
            for ($li=1; $li<count($eLines); $li++) {
                $c .= '<w:p><w:r><w:t>' . htmlspecialchars($eLines[$li]) . '</w:t></w:r></w:p>';
            }
        }
    }

    return $c;
}

function docxTable(array $rows) {
    $c  = '<w:tbl><w:tblPr>';
    $c .= '<w:tblW w:w="9000" w:type="dxa"/>';
    $c .= '<w:tblBorders>'
        . '<w:top w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:left w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:bottom w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:right w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:insideH w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:insideV w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '</w:tblBorders></w:tblPr>';
    foreach ($rows as [$label, $value]) {
        $c .= '<w:tr><w:trPr><w:trHeight w:val="400" w:type="auto"/></w:trPr>';
        $c .= '<w:tc><w:tcPr><w:tcW w:w="3000" w:type="dxa"/><w:shd w:fill="D3D3D3" w:val="clear"/></w:tcPr>'
            . '<w:p><w:pPr><w:ind w:left="80"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($label) . '</w:t></w:r></w:p></w:tc>';
        $c .= '<w:tc><w:tcPr><w:tcW w:w="6000" w:type="dxa"/></w:tcPr>'
            . '<w:p><w:pPr><w:ind w:left="80"/></w:pPr><w:r><w:t>' . htmlspecialchars($value) . '</w:t></w:r></w:p></w:tc>';
        $c .= '</w:tr>';
    }
    $c .= '</w:tbl>';
    return $c;
}

function docxIndentedText($text) {
    $c = '';
    foreach (explode("\n", $text) as $line) {
        $c .= '<w:p><w:pPr><w:ind w:left="720"/></w:pPr><w:r><w:t xml:space="preserve">' . htmlspecialchars(trim($line) ?: ' ') . '</w:t></w:r></w:p>';
    }
    return $c;
}

function docxBulletList($text) {
    $c = '';
    foreach (explode("\n", $text) as $item) {
        $item = trim($item);
        $item = ltrim($item, '-•*\t ');
        $item = trim($item);
        if ($item !== '') {
            $c .= '<w:p>'
                . '<w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr>'
                . '<w:r><w:t xml:space="preserve">&#x2022;  ' . htmlspecialchars($item) . '</w:t></w:r>'
                . '</w:p>';
        }
    }
    return $c;
}

/* ══════════════════════════════════════════════════════════════════════════════
 * FEATURE 3: WYSIWYG OUTPUT CONSISTENCY — helpers added (non-breaking)
 * These functions are NEW additions that improve output fidelity.
 * They do NOT modify or replace any existing function above.
 * ══════════════════════════════════════════════════════════════════════════════ */

/**
 * docxTableMultiLine — enhanced table that handles multi-line values in cells.
 * Replaces the single-paragraph value cell in docxTable with one paragraph
 * per line, so long text is not cut off in the rendered output.
 * Called from buildProjectProposalContent via the patched version below.
 */
function docxTableMultiLine(array $rows) {
    $c  = '<w:tbl><w:tblPr>';
    $c .= '<w:tblW w:w="9000" w:type="dxa"/>';
    $c .= '<w:tblBorders>'
        . '<w:top w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:left w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:bottom w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:right w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:insideH w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '<w:insideV w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        . '</w:tblBorders></w:tblPr>';

    foreach ($rows as [$label, $value]) {
        $c .= '<w:tr><w:trPr><w:trHeight w:val="400" w:type="auto"/></w:trPr>';
        // Label cell (bold, grey background)
        $c .= '<w:tc><w:tcPr><w:tcW w:w="3000" w:type="dxa"/><w:shd w:fill="D3D3D3" w:val="clear"/></w:tcPr>'
            . '<w:p><w:pPr><w:ind w:left="80"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">' . htmlspecialchars($label) . '</w:t></w:r></w:p></w:tc>';

        // Value cell — render each line as a paragraph to preserve newlines
        $valueLines = explode("\n", (string)$value);
        $c .= '<w:tc><w:tcPr><w:tcW w:w="6000" w:type="dxa"/></w:tcPr>';
        foreach ($valueLines as $li => $line) {
            $lineText = htmlspecialchars(trim($line));
            if ($lineText === '') $lineText = ' ';
            $c .= '<w:p><w:pPr><w:ind w:left="80"/>' . ($li > 0 ? '' : '') . '</w:pPr>'
                . '<w:r><w:t xml:space="preserve">' . $lineText . '</w:t></w:r></w:p>';
        }
        $c .= '</w:tc>';

        $c .= '</w:tr>';
    }
    $c .= '</w:tbl>';
    return $c;
}

/**
 * docxIndentedTextWysiwyg — like docxIndentedText but preserves blank separator lines
 * exactly as the user typed them, producing a WYSIWYG output.
 */
function docxIndentedTextWysiwyg($text) {
    $c = '';
    $lines = explode("\n", (string)$text);
    foreach ($lines as $line) {
        $lineText = htmlspecialchars(trim($line));
        $c .= '<w:p><w:pPr><w:ind w:left="720"/></w:pPr>'
            . '<w:r><w:t xml:space="preserve">' . ($lineText !== '' ? $lineText : ' ') . '</w:t></w:r>'
            . '</w:p>';
    }
    return $c;
}

/**
 * buildProjectProposalContentWysiwyg — drop-in replacement for buildProjectProposalContent
 * that uses the multi-line table and wysiwyg text helpers.
 * Called instead of the original when the template is 'Project Proposal'.
 */
function buildProjectProposalContentWysiwyg($data, $organizationName = null) {
    $c = '';
    $orgName = htmlspecialchars($organizationName ?: ($data['organization'] ?? ''));

    // ── Control Number ──
    if (!empty($data['control_number'])) {
        $c .= '<w:p><w:pPr><w:jc w:val="right"/></w:pPr>'
            . '<w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="2F5233"/></w:rPr>'
            . '<w:t>Control No.: ' . htmlspecialchars($data['control_number']) . '</w:t></w:r></w:p>';
    }

    // ── Date ──
    if (!empty($data['proposal_date'])) {
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($data['proposal_date']) . '</w:t></w:r></w:p><w:p/>';
    }

    // ── Recipient 1 — name + title from site_settings ──
    if (!empty($data['recipient_1'])) {
        $r1title = htmlspecialchars(trim($data['recipient_1_title'] ?? 'Interim University President'));
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars(trim($data['recipient_1'])) . '</w:t></w:r></w:p>';
        $c .= '<w:p><w:r><w:t>' . $r1title . '</w:t></w:r></w:p><w:p/>';
    }

    // ── Recipient 2 — name + title from site_settings ──
    if (!empty($data['recipient_2'])) {
        $r2title = htmlspecialchars(trim($data['recipient_2_title'] ?? 'Dean, Office of Student Affairs and Services'));
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars(trim($data['recipient_2'])) . '</w:t></w:r></w:p>';
        $c .= '<w:p><w:r><w:t>' . $r2title . '</w:t></w:r></w:p><w:p/>';
    }

    // ── Dear line ──
    $dearName = trim($data['recipient_2'] ?? '');
    if ($dearName) {
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Dear ' . htmlspecialchars($dearName) . ',</w:t></w:r></w:p>';
    }

    // ── Opening statement — wysiwyg multi-line ──
    if (!empty($data['opening_statement'])) {
        $c .= '<w:p/>';
        foreach (explode("\n", $data['opening_statement']) as $line) {
            $lineText = htmlspecialchars(trim($line));
            $c .= '<w:p><w:r><w:t xml:space="preserve">' . ($lineText ?: ' ') . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p/>';
    }

    // ── PROJECT PROPOSAL heading ──
    $c .= '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr><w:t>PROJECT PROPOSAL</w:t></w:r></w:p><w:p/>';

    // ── I. Identifying Information — multi-line table ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>I. Identifying Information</w:t></w:r></w:p>';
    $c .= docxTableMultiLine([
        ['Organization',              $data['organization']         ?? ''],
        ['Project Title',             $data['project_title']        ?? ''],
        ['Type of Project',           $data['project_type']         ?? ''],
        ['Project Involvement',       $data['project_involvement']  ?? ''],
        ['Project Location',          $data['project_location']     ?? ''],
        ['Proposed Start Date & Time',$data['proposed_start_date']  ?? ''],
        ['Proposed Completion Date',  $data['proposed_end_date']    ?? ''],
        ['Number of Participants',    $data['number_participants']  ?? ''],
    ]);
    $c .= '<w:p/>';

    // ── II. Project Description ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>II. Project Description</w:t></w:r></w:p>';

    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>A. SUMMARY OF THE PROJECT</w:t></w:r></w:p>';
    $c .= docxIndentedTextWysiwyg($data['project_summary'] ?? '');
    $c .= '<w:p/>';

    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>B. PROJECT GOAL AND OBJECTIVES</w:t></w:r></w:p>';
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Goal:</w:t></w:r></w:p>';
    $c .= docxIndentedTextWysiwyg($data['project_goal'] ?? '');
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Objectives:</w:t></w:r></w:p>';
    if (!empty($data['project_objectives'])) {
        $n = 1;
        foreach (explode("\n", $data['project_objectives']) as $obj) {
            $obj = trim($obj);
            if ($obj !== '') {
                $c .= '<w:p><w:pPr><w:ind w:left="720"/></w:pPr>'
                    . '<w:r><w:t xml:space="preserve">' . $n++ . '. ' . htmlspecialchars($obj) . '</w:t></w:r></w:p>';
            }
        }
    }
    $c .= '<w:p/>';

    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="22"/></w:rPr><w:t>C. EXPECTED OUTPUTS</w:t></w:r></w:p>';
    $c .= docxBulletList($data['expected_outputs'] ?? '');
    $c .= '<w:p/>';

    // ── III. Budget — multi-line table ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>III. Budget</w:t></w:r></w:p>';
    $c .= docxTableMultiLine([
        ['Source of Fund',           $data['budget_source']  ?? ''],
        ['Partner/Donation/Subsidy', $data['budget_partner'] ?? ''],
        ['Total Project Cost',       $data['budget_total']   ?? ''],
    ]);
    $c .= '<w:p/>';

    // ── IV. Monitoring and Evaluation ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>IV. Monitoring and Evaluation</w:t></w:r></w:p>';
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Monitoring:</w:t></w:r></w:p>';
    $c .= docxBulletList($data['monitoring_details'] ?? '');
    $c .= '<w:p/>';
    $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Evaluation Strategy:</w:t></w:r></w:p>';
    $c .= docxBulletList($data['evaluation_details'] ?? '');
    $c .= '<w:p/>';

    // ── V. Security Plan ──
    $c .= '<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>V. Security Plan</w:t></w:r></w:p>';
    $c .= docxBulletList($data['security_plan'] ?? '');
    $c .= '<w:p/><w:p/>';

    // ── Closing statement ──
    if (!empty($data['closing_statement'])) {
        foreach (explode("\n", $data['closing_statement']) as $line) {
            $c .= '<w:p><w:r><w:rPr><w:i/></w:rPr>'
                . '<w:t xml:space="preserve">' . htmlspecialchars(trim($line) ?: ' ') . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p/>';
    }

    // ── Sincerely ──
    $c .= '<w:p><w:r><w:t>Sincerely,</w:t></w:r></w:p><w:p/><w:p/>';

    // ── Sender ──
    if (!empty($data['sender_name'])) {
        $sLines = array_values(array_filter(array_map('trim', explode("\n", $data['sender_name']))));
        if (!empty($sLines)) {
            $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($sLines[0]) . '</w:t></w:r></w:p>';
            for ($li = 1; $li < count($sLines); $li++) {
                $c .= '<w:p><w:r><w:t>' . htmlspecialchars($sLines[$li]) . '</w:t></w:r></w:p>';
            }
        }
    }
    $c .= '<w:p/>';

    // ── Noted by ──
    $noteList = ['adviser_name','co_adviser_name'];
    for ($si = 1; $si <= 5; $si++) { $noteList[] = 'additional_signer_' . $si; }
    foreach ($noteList as $sigKey) {
        if (empty($data[$sigKey])) continue;
        $sigLines = array_values(array_filter(array_map('trim', explode("\n", $data[$sigKey]))));
        if (empty($sigLines)) continue;
        $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($sigLines[0]) . '</w:t></w:r></w:p>';
        for ($li = 1; $li < count($sigLines); $li++) {
            $c .= '<w:p><w:r><w:t>' . htmlspecialchars($sigLines[$li]) . '</w:t></w:r></w:p>';
        }
        $c .= '<w:p/>';
    }

    // ── Endorsed by ──
    if (!empty($data['endorsed_by'])) {
        $eLines = array_values(array_filter(array_map('trim', explode("\n", $data['endorsed_by']))));
        if (!empty($eLines)) {
            $c .= '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t>' . htmlspecialchars($eLines[0]) . '</w:t></w:r></w:p>';
            for ($li = 1; $li < count($eLines); $li++) {
                $c .= '<w:p><w:r><w:t>' . htmlspecialchars($eLines[$li]) . '</w:t></w:r></w:p>';
            }
        }
    }

    return $c;
}